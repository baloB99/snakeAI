public class Timer {
    long startTime;

    double start() {
        startTime = System.currentTimeMillis();


        return startTime;
    }

}