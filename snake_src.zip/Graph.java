import java.util.*;

public class Graph{

    ArrayList<Vertex> vertices = new ArrayList<Vertex>();
    ArrayList<ArrayList<Vertex>> board = new ArrayList<ArrayList<Vertex>>();
    int graphOrder;

    public Graph(int order) {
        this.graphOrder = order;

        for(int rows = 0; rows<50; rows++) {
            ArrayList<Vertex> row = new ArrayList<Vertex>();
            for(int cols = 0; cols<50; cols++) {
                Vertex v = new Vertex(50*rows + cols);
                v.x = cols;
                v.y = rows;
                row.add(v);
            }
            this.board.add(row);
        }


        for(int i = 0; i < order; i++) {
            this.addVertex();
        }

        //vertex with largest degree
        Vertex p = vertices.get(getBiggestVertex());
        int degree = p.getDegree();

        while(getBiggestVertex() != -1) {
            int vertexNumber = getBiggestVertex();
            Vertex v = vertices.get(vertexNumber);
            v.setColor(degree);//set this to always be max degree
        }

    }

    public void makeEdges() {
        for(int row = 0; row<50; row++) {
            for(int col = 0; col<50; col++) {
                Vertex v = board.get(row).get(col);

                if(row-1 >= 0) { //up

                    Vertex w = board.get(row-1).get(col);
                    if(w.type == -1 || w.type == 15 || w.type == 100) {
                        v.addAdjacency(w);
                    }

                }

                if(row+1 < 50) { //down
                    Vertex w = board.get(row+1).get(col);
                    if(w.type == -1 || w.type == 15 || w.type == 100) {
                        v.addAdjacency(w);
                    }
                }

                if(col-1 >= 0) { //left
                    Vertex w = board.get(row).get(col-1);
                    if(w.type == -1 || w.type == 15 || w.type == 100) {
                        v.addAdjacency(w);
                    }
                }

                if(col+1 < 50) { //right
                    Vertex w = board.get(row).get(col+1);
                    if(w.type == -1 || w.type == 15 || w.type == 100) {
                        v.addAdjacency(w);
                    }
                }
            }
        }
    }

    void addVertex() {
        Vertex vertex = new Vertex(vertices.size());
        vertices.add(vertex);
    }

    int getBiggestVertex() {
        int vmax = -1;
        int noOfUncoloured = 0; //Initialized to make sure we find at least 1 uncolored vertex
        Vertex vUncoloured = null;

        for(Vertex v  : vertices) {
            if(v.colour == -1) {
                noOfUncoloured += 1; //increment the number of uncolored vertices
                vUncoloured = v;
                vmax = vUncoloured.vertexNumber;
                break;
            }
        }

        //if after the first loop we have 0 uncolored vertices,
        // there is no need to carry on the method
        // return vmax as it will be -1 at this point
        if(noOfUncoloured==0) {
            return vmax;
        }

        for(Vertex v : vertices) {
            if(v.colour == -1) {
                if(v.getDegree() > vertices.get(vmax).getDegree()) {
                    vmax = v.vertexNumber;
                }

                else if(v.getDegree() == vertices.get(vmax).getDegree()) {
                    if(v.vertexNumber < vUncoloured.vertexNumber) {
                        vmax = v.vertexNumber;
                    }
                }
            }
        }

        return vmax;
    }



    public static void main(String args[]) {
        new Graph(2500);
    }

}