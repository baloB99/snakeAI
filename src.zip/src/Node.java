
public class Node {
	
	Node parent;
	int posx, posy;
	double f, g, h;

	public Node(int x, int y) 
	{
		this.posx =x;
		this.posy =y;
	}
	
	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	public Node getParent() {
		return this.parent;
	}
	
	public void setNodeG(double g) {
		this.g = g;
	}
	
	public double getNodeG() {
		return this.g;
	}
	public void setNodeF(double f) {
		this.f = f;
	}
	
	public double getNodeF() {
		return this.f;
	}
	
	
}
