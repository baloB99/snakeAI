import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Set;

public class AstarSearch {

	Integer[][] board;
	
	public AstarSearch(Integer[][] board) {
		this.board = board;
	}
	
	public boolean isBlocked(int x, int y) {
		
		if(board[x][y] == 5) {
			return true;
		}
		else {
			return false;
		}
	}
	public boolean isValid(int x, int y){
	    
	    return (x >= 0) && (x < 50) && (y >= 0) && (y < 50);
	}
	
	public ArrayList<Node> getChildren(Node current){
		ArrayList<Node> children = new ArrayList<Node>();
		
		Node left = new Node(current.posx, current.posy - 1);
		Node right = new Node(current.posx, current.posy + 1);
		Node top = new Node(current.posx - 1, current.posy);
		Node bottom = new Node(current.posx + 1, current.posy);
		
		children.add(left);
		children.add(right);
		children.add(top);
		children.add(bottom);
		
		for(int i=0; i < children.size(); i++) {
			if(isValid(children.get(i).posx, children.get(i).posy) == true) {
				
				if(isBlocked(children.get(i).posx, children.get(i).posy) == true) {
					children.remove(i);
				}
				
			}
		}
		return children;
	}
	
	public void printBoard(int width, int height) {
    	
    	for(int i=0; i <width; i++) {
    		for(int j=0; j < height; j++) {
    			System.err.print(board[i][j]);
    		}
    		System.err.println();
    	}
    }
	
	public void astarPath(Node start, Node goal){
		
		Set<Node> explored = new HashSet<Node>();

        PriorityQueue<Node> queue = new PriorityQueue<Node>(20, 
                new Comparator<Node>(){
                         //override compare method
         public int compare(Node i, Node j){
        	 
            if(i.f > j.f){
                return 1;
            }

            else if (i.f < j.f){
                return -1;
            }

            else{
                return 0;
            }
         }

        });
                

        //cost from start
        start.setNodeG(0);
        start.setParent(null);
        queue.add(start);

        boolean found = false;

        while((!queue.isEmpty())&&(!found)){

        	Node current = queue.poll();

            explored.add(current);

                
            if(current.posx == goal.posx && current.posy == goal.posy){
                    found = true;
            }

            for(Node child : getChildren(current)){
                double temp_g = current.g;
                
                child.h = Math.abs(child.posx - goal.posx) + Math.abs(child.posy - goal.posy);
              
            	temp_g = temp_g + 1;
              
            	double temp_f = temp_g + child.h;
                
                if((queue.contains(child)) && 
                    (child.f < temp_f)){
                    continue;
                }

                else if((explored.contains(child)) &&
                    (temp_f > child.f)){
                	continue;
                }
                else {
                	
                	child.setParent(current);
                    child.setNodeG(temp_g);
                    child.setNodeF(temp_f);

                    if(queue.contains(child)){ 
                            queue.remove(child);
                    }

                    queue.add(child);
                }
              }
        }
        
	}
	
}
