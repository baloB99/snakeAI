import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import za.ac.wits.snake.DevelopmentAgent;

public class MyAgent extends DevelopmentAgent {
	
	GenerateBoard generateBoard;
	Node start;
	
    public static void main(String args[]) {
        MyAgent agent = new MyAgent();
        MyAgent.start(agent, args);
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            String initString = br.readLine();
            String[] temp = initString.split(" ");
            int nSnakes = Integer.parseInt(temp[0]);
            int width =Integer.parseInt(temp[1]);
            int height =Integer.parseInt(temp[2]);
            generateBoard =new GenerateBoard(width, height);
            
            
            generateBoard.createBoard();
            
            while (true) {
                String line = br.readLine();
                if (line.contains("Game Over")) {
                    break;
                }
                String apple1 = line;
                //do stuff with apples
                String[] applepos =apple1.split(" ");
                int ax = Integer.parseInt(applepos[0]);
                int ay = Integer.parseInt(applepos[1]);
                Node goal = new Node(ax, ay);
                for (int zombie=0; zombie<6; zombie++) {
                	String zombieLine=br.readLine();
                	
                	String[] corners =zombieLine.split(" ");
//                  5 represents the number of an obstacle.
                	generateBoard.drawObstacles(corners, 5);
                
                }

                int mySnakeNum = Integer.parseInt(br.readLine());
                for (int i = 0; i < nSnakes; i++) {
                    String snakeLine = br.readLine();
                    String[] pieces =snakeLine.split(" ");
                    if (i == mySnakeNum) {
                        //hey! That's me :)
                    	if (pieces[0].equals("alive"))
                    	{
                    		String[] headXY = pieces[3].split(",");
                            int hx = Integer.parseInt(headXY[0]);
                            int hy = Integer.parseInt(headXY[1]);
                            start = new Node(hx, hy);
                    		String[] sliced =Arrays.copyOfRange(pieces, 3, pieces.length-1);
                    		generateBoard.drawObstacles(sliced, 5);
                    		
                    	}
                    }
                    //do stuff with other snakes
                    if (pieces[0].equals("alive") && i != mySnakeNum) 
                    {
                    	String[] sliced =Arrays.copyOfRange(pieces, 3, pieces.length-1);
                    	generateBoard.drawObstacles(sliced, 5);
                    }
                }
                
                AstarSearch astarSearch = new AstarSearch(generateBoard.board);
                
                astarSearch.printBoard(width, height);
                System.err.println("Skip");
//                System.err.println(path.size());
                //finished reading, calculate move:
                int move = new Random().nextInt(4);
                System.out.println(move);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}