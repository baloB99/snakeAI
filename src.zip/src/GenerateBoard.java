//import java.util.*;

public class GenerateBoard {
	
	int width;
	int height;
	Integer[][] board;
	public GenerateBoard(int width, int height) 
	{
		this.width =width;
		this.height =height;
	}
	
	public Integer[][] createBoard() 
	{
		board =new Integer[width][height];
		for(int i=0; i < height; i++) 
		{
			for (int j =0; j < width; j++) 
			{
				board[i][j] =0;
			}
		}
		
		return board;
	}
	
	public void drawObstacles(String[] corners, int snakeNum) 
	{
		
		for (int i=0; i < corners.length-1; i++) 
		{
			String[] corner1 = corners[i].split(",");
			String[] corner2 = corners[i+1].split(",");
			int x1 =Integer.parseInt(corner1[0]);
			int y1 =Integer.parseInt(corner1[1]);
			
			int x2 =Integer.parseInt(corner2[0]);
			int y2 =Integer.parseInt(corner2[1]);
			
			if (y1 == y2) 
			{
				if (x1 > x2) 
				{
					for (int j=x2; j <= x1; j++) 
					{
						board[j][y1] =snakeNum;
					}
				}
				else 
				{
					for (int j=x1; j <=x2; j++) 
					{
						board[j][y1] =snakeNum;
					}
				}
			}
			else if (x1 == x2) 
			{
				if (y1 > y2) 
				{
					for (int j=y2; j <= y1; j++) 
					{
						board[x1][j] =snakeNum;
					}
				}
				else 
				{
					for (int j=y1; j <= y2; j++) 
					{
						board[x1][j] =snakeNum;
					}
				}	
			}
		}
	}
	
}